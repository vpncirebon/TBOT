// cmd/cekstatus.js - Optimized v2.0
'use strict';

const db = require('../data/db');

module.exports = function cekstatusCmd(bot, chatId, msgId) {
  bot.editMessageText('⏳ <i>Mengecek status akun...</i>', {
    chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
  }).catch(() => {});

  const LABEL = {
    SSH: '⚪ SSH / OpenVPN', VMESS: '🔵 xRay VMess',
    VLESS: '🟡 xRay VLess', TROJAN: '🟠 xRay Trojan', ZIVPN: '🟢 UDP ZivPN'
  };

  db.all(
    "SELECT product_type, username, expired_at, server_ip FROM transactions WHERE chat_id=? AND status='completed' AND product_type NOT IN ('', 'TOPUP') ORDER BY expired_at DESC LIMIT 10",
    [chatId],
    (err, rows) => {
      if (err) {
        console.error('[cekstatusCmd] ❌', err.message);
        return bot.editMessageText('❌ Gagal cek status.', {
          chat_id: chatId, message_id: msgId,
          reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
        }).catch(() => {});
      }

      let text = `┌─────────────────┐\n│  📋 STATUS AKUN\n└─────────────────┘\n\n`;

      if (!rows?.length) {
        text += '📭 Belum ada akun.\n\nBeli sekarang di menu Orders Account!';
      } else {
        const now = new Date();
        rows.forEach((r, i) => {
          const exp        = r.expired_at ? new Date(r.expired_at) : null;
          const sisaHari   = exp && exp > now ? Math.ceil((exp - now) / 86400000) : 0;
          const expStr     = r.expired_at ? r.expired_at.slice(0, 16) : '-';
          const statusIcon = sisaHari > 3 ? '🟢' : sisaHari > 0 ? '🟡' : '🔴';
          const label      = LABEL[r.product_type] || r.product_type;

          text +=
            `${i + 1}. ${statusIcon} <b>${label}</b>\n` +
            `   👤 ${r.username || '-'}\n` +
            `   📅 Expired: ${expStr}\n` +
            `   ⏱ Sisa: ${sisaHari > 0 ? sisaHari + ' hari' : '<b>EXPIRED</b>'}\n\n`;
        });
      }

      bot.editMessageText(text, {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔄 Extend Akun', callback_data: 'renew_menu'   }],
            [{ text: '🔃 Kembali',     callback_data: 'menu_back'    }]
          ]
        }
      }).catch(() => {});
    }
  );
};
