module.exports = {
  members: {
    ssh:      { perDay: 334 },
    vmess:    { perDay: 334 },
    vless:    { perDay: 334 },
    trojan:   { perDay: 334 },
    udpzivpn: { perDay: 334 }
  },
  reseller: {
    ssh:      { perDay: 300 },
    vmess:    { perDay: 300 },
    vless:    { perDay: 300 },
    trojan:   { perDay: 300 },
    udpzivpn: { perDay: 300 }
  }
};
